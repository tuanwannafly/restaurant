package com.restaurant.data;

import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingWorker;

import com.restaurant.dao.EmployeeDAO;
import com.restaurant.dao.MenuItemDAO;
import com.restaurant.dao.OrderDAO;
import com.restaurant.dao.RestaurantDAO;
import com.restaurant.dao.TableDAO;
import com.restaurant.dao.UserDAO;
import com.restaurant.model.Employee;
import com.restaurant.model.MenuItem;
import com.restaurant.model.Order;
import com.restaurant.model.Restaurant;
import com.restaurant.model.TableItem;
import com.restaurant.session.AppSession;
import com.restaurant.session.RbacGuard;

/**
 * DataManager — lớp duy nhất mà UI biết đến.
 * Phiên bản JDBC: thay thế hoàn toàn ApiClient (REST API).
 * Giao diện public giữ nguyên → tất cả Panel không cần đổi.
 *
 * <p><b>Phase 2C — Session Guard:</b><br>
 * Mọi method write (add/update/delete) đều gọi {@link #checkSession()} trước
 * khi delegate xuống DAO. restaurantId KHÔNG được truyền từ UI — DataManager
 * tự lấy qua AppSession, DAO cũng tự gắn khi cần.<br>
 * SUPER_ADMIN được miễn guard (restaurantId == 0 vẫn OK).
 */
public class DataManager {

    private static DataManager instance;

    private final MenuItemDAO menuItemDAO  = new MenuItemDAO();
    private final TableDAO    tableDAO     = new TableDAO();
    private final OrderDAO    orderDAO     = new OrderDAO();
    private final EmployeeDAO employeeDAO  = new EmployeeDAO();
    private final UserDAO       userDAO       = new UserDAO();
    private final RestaurantDAO restaurantDAO = new RestaurantDAO();

    private DataManager() {}

    public static DataManager getInstance() {
        if (instance == null) instance = new DataManager();
        return instance;
    }


    // ═══════════════════════════════════════════════════════
    //  SESSION GUARD
    // ═══════════════════════════════════════════════════════

    /**
     * Kiểm tra phiên làm việc hợp lệ trước khi thực hiện thao tác write.
     *
     * <p>Điều kiện bị chặn: {@code restaurantId == 0} VÀ KHÔNG phải SUPER_ADMIN.
     * Bao gồm cả trường hợp chưa đăng nhập (logout → restaurantId=0, role=null).
     *
     * <p>SUPER_ADMIN với {@code restaurantId == 0} được miễn — có thể thao tác
     * toàn hệ thống.
     *
     * @throws IllegalStateException nếu chưa đăng nhập hoặc thiếu tenant
     */
    private void checkSession() {
        AppSession session = AppSession.getInstance();
        if (session.getRestaurantId() == 0
                && !RbacGuard.getInstance().isSuperAdmin()) {
            System.err.println("[DataManager] checkSession thất bại:"
                    + " chưa đăng nhập hoặc restaurantId == 0");
            throw new IllegalStateException("Chưa đăng nhập");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  MENU ITEMS
    // ═══════════════════════════════════════════════════════

    public List<MenuItem> getMenuItems() {
        try { return menuItemDAO.getAll(); }
        catch (Exception e) {
            System.err.println("[DataManager] getMenuItems lỗi: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public MenuItem addMenuItem(MenuItem item) {
        checkSession();
        try { return menuItemDAO.create(item); }
        catch (Exception e) {
            System.err.println("[DataManager] addMenuItem lỗi: " + e.getMessage());
            return item;
        }
    }

    public MenuItem updateMenuItem(MenuItem updated) {
        checkSession();
        try { return menuItemDAO.update(updated); }
        catch (Exception e) {
            System.err.println("[DataManager] updateMenuItem lỗi: " + e.getMessage());
            return updated;
        }
    }

    public void deleteMenuItem(String id) {
        checkSession();
        try { menuItemDAO.delete(id); }
        catch (Exception e) { System.err.println("[DataManager] deleteMenuItem lỗi: " + e.getMessage()); }
    }

    // ═══════════════════════════════════════════════════════
    //  TABLES
    // ═══════════════════════════════════════════════════════

    public List<TableItem> getTables() {
        try { return tableDAO.getAll(); }
        catch (Exception e) {
            System.err.println("[DataManager] getTables lỗi: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public TableItem addTable(TableItem table) {
        checkSession();
        try { return tableDAO.create(table); }
        catch (Exception e) {
            System.err.println("[DataManager] addTable lỗi: " + e.getMessage());
            return table;
        }
    }

    public TableItem updateTable(TableItem updated) {
        checkSession();
        try { return tableDAO.update(updated); }
        catch (Exception e) {
            System.err.println("[DataManager] updateTable lỗi: " + e.getMessage());
            return updated;
        }
    }

    public void deleteTable(String id) {
        checkSession();
        try { tableDAO.delete(id); }
        catch (Exception e) { System.err.println("[DataManager] deleteTable lỗi: " + e.getMessage()); }
    }

    // ═══════════════════════════════════════════════════════
    //  EMPLOYEES
    // ═══════════════════════════════════════════════════════

    public List<Employee> getEmployees() {
        try { return employeeDAO.findAll(); }
        catch (Exception e) {
            System.err.println("[DataManager] getEmployees lỗi: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Như {@link #getEmployees()} nhưng kèm trạng thái tài khoản cho mỗi nhân viên.
     * Dùng một query có CASE WHEN để tránh N+1.
     * Gọi khi cần hiển thị cột "Tài khoản" (RESTAURANT_ADMIN).
     */
    public List<Employee> getEmployeesWithAccountStatus() {
        try { return employeeDAO.findAllWithAccountStatus(); }
        catch (Exception e) {
            System.err.println("[DataManager] getEmployeesWithAccountStatus lỗi: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public Employee addEmployee(Employee emp) {
        checkSession();
        try { return employeeDAO.add(emp); }
        catch (Exception e) {
            System.err.println("[DataManager] addEmployee lỗi: " + e.getMessage());
            return emp;
        }
    }

    public Employee updateEmployee(Employee updated) {
        checkSession();
        try { return employeeDAO.update(updated); }
        catch (Exception e) {
            System.err.println("[DataManager] updateEmployee lỗi: " + e.getMessage());
            return updated;
        }
    }

    public void deleteEmployee(String id) {
        checkSession();
        try { employeeDAO.delete(id); }
        catch (Exception e) { System.err.println("[DataManager] deleteEmployee lỗi: " + e.getMessage()); }
    }

    /** ID được sinh tự động bởi DB sequence, trả về placeholder */
    public String generateEmployeeId() { return "AUTO"; }

    // ═══════════════════════════════════════════════════════
    //  ORDERS
    // ═══════════════════════════════════════════════════════

    public List<Order> getOrders() {
        try { return orderDAO.getAll(); }
        catch (Exception e) {
            System.err.println("[DataManager] getOrders lỗi: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public Order addOrder(Order order) {
        checkSession();
        try { return orderDAO.create(order); }
        catch (Exception e) {
            System.err.println("[DataManager] addOrder lỗi: " + e.getMessage());
            return order;
        }
    }

    public Order updateOrder(Order updated) {
        checkSession();
        try { return orderDAO.update(updated); }
        catch (Exception e) {
            System.err.println("[DataManager] updateOrder lỗi: " + e.getMessage());
            return updated;
        }
    }

    public void deleteOrder(String id) {
        checkSession();
        try { orderDAO.delete(id); }
        catch (Exception e) { System.err.println("[DataManager] deleteOrder lỗi: " + e.getMessage()); }
    }

    // ═══════════════════════════════════════════════════════
    //  Async helper: chạy task trong background, sau đó gọi callback trên EDT
    // ═══════════════════════════════════════════════════════

    public static void runAsync(Runnable task, Runnable onDone) {
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() { task.run(); return null; }
            @Override protected void done() { if (onDone != null) onDone.run(); }
        }.execute();
    }

    // ═══════════════════════════════════════════════════════
    //  RESTAURANT  (G1: in-memory cache với TTL 30s)
    // ═══════════════════════════════════════════════════════

    /** Cache nhà hàng hiện tại — tránh query DB mỗi lần poll. */
    private volatile Restaurant cachedRestaurant    = null;
    private volatile long       restaurantCacheTime = 0;
    private static final long   CACHE_TTL_MS        = 30_000; // 30 giây

    /**
     * Lấy thông tin nhà hàng của phiên hiện tại.
     * Kết quả được cache tối đa {@link #CACHE_TTL_MS} ms để tránh query DB
     * liên tục khi nhiều panel/poll cùng gọi trong thời gian ngắn.
     * Cache tự động bị invalidate sau khi admin lưu thay đổi.
     */
    public Restaurant getMyRestaurant() {
        long rid = AppSession.getInstance().getRestaurantId();
        if (rid == 0) return null;
        long now = System.currentTimeMillis();
        if (cachedRestaurant == null || now - restaurantCacheTime > CACHE_TTL_MS) {
            cachedRestaurant    = restaurantDAO.findByIdPublic(rid);
            restaurantCacheTime = now;
        }
        return cachedRestaurant;
    }

    /**
     * Xóa cache nhà hàng — gọi ngay sau khi admin update thành công.
     * Lần gọi {@link #getMyRestaurant()} tiếp theo sẽ fetch lại từ DB,
     * đảm bảo mọi staff trong cùng session thấy thông tin mới khi refresh.
     */
    public void invalidateRestaurantCache() {
        cachedRestaurant    = null;
        restaurantCacheTime = 0;
    }

    /**
     * Cập nhật nhà hàng (RESTAURANT_ADMIN chỉ được sửa nhà hàng của mình).
     * Tự động invalidate cache sau khi lưu thành công.
     */
    public void updateMyRestaurant(Restaurant r) {
        checkSession();
        restaurantDAO.updateByAdmin(r); // throws on auth violation
        invalidateRestaurantCache();    // G1: force re-fetch cho mọi panel/poll tiếp theo
    }

    // ═══════════════════════════════════════════════════════
    //  USER / STAFF
    // ═══════════════════════════════════════════════════════

    /** Tạo tài khoản staff mới (chỉ RESTAURANT_ADMIN). */
    public long registerStaff(String name, String email, String password, String roleName) {
        checkSession();
        return userDAO.registerStaff(name, email, password, roleName,
                                     AppSession.getInstance().getRestaurantId());
    }

    /** Cập nhật thông tin cá nhân của userId. */
    public void updateOwnProfile(long userId, String name, String phone, String address) {
        userDAO.updateOwnProfile(userId, name, phone, address);
    }

    /**
     * Trả về bản ghi Employee liên kết với user đang đăng nhập.
     * Dùng để pre-fill phone/address trong "Hồ sơ của tôi".
     * Trả về {@code null} nếu user chưa có employee record (e.g. SUPER_ADMIN).
     */
    public Employee getOwnEmployeeInfo() {
        long uid = AppSession.getInstance().getUserId();
        return employeeDAO.findByUserId(uid).orElse(null);
    }

    /** Đổi mật khẩu cá nhân. */
    public void changeOwnPassword(long userId, String oldPw, String newPw) {
        userDAO.changeOwnPassword(userId, oldPw, newPw);
    }

    /** Tạo token đặt lại mật khẩu (hết hạn 15 phút). Trả null nếu email không tồn tại. */
    public String generatePasswordResetToken(String email) {
        return userDAO.generatePasswordResetToken(email);
    }

    /** Kiểm tra token hợp lệ (tồn tại, chưa dùng, chưa hết hạn). */
    public boolean validateResetToken(String token) {
        return userDAO.validateResetToken(token);
    }

    /** Đặt lại mật khẩu bằng token một lần. Trả false nếu token không hợp lệ. */
    public boolean resetPasswordWithToken(String token, String newPassword) {
        return userDAO.resetPasswordWithToken(token, newPassword);
    }

    /** Dọn dẹp token hết hạn — gọi khi khởi động ứng dụng. */
    public void cleanupExpiredResetTokens() {
        userDAO.cleanupExpiredResetTokens();
    }

    // ═══════════════════════════════════════════════════════
    //  DASHBOARD STATS
    // ═══════════════════════════════════════════════════════

    public double getTodayRevenue() {
        return getOrders().stream()
                .filter(o -> o.getStatus() == Order.Status.HOAN_THANH)
                .mapToDouble(Order::getTotalAmount).sum();
    }

    public long getTodayOrderCount() {
        return getOrders().stream()
                .filter(o -> o.getStatus() != Order.Status.DA_HUY).count();
    }

    public long getServingTableCount() {
        return getTables().stream()
                .filter(t -> t.getStatus() == TableItem.Status.BAN).count();
    }

    public long getTotalMenuItemsSold() {
        return getOrders().stream()
                .filter(o -> o.getStatus() == Order.Status.HOAN_THANH)
                .flatMap(o -> o.getItems().stream())
                .mapToLong(Order.OrderItem::getQuantity).sum();
    }
}